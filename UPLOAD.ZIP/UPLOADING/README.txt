Hi. Welcome to tools pack I prepared for programming both ESP32 DO-IT board and NodeMCU with ESP8266. Steps are simple.
Here are two parts. In the first one I explain how to upload firmware and in the second one how to upload website files.

PART 1
======
1. Copy latest firmware into "Firmware" directory. The file for ESP32 should be named: UroflowESP32.ino_ESP32.bin. The file for ESP8266 should be named UroflowESP32.ino_ESP8266.bin.
2. Connect your uroflow device via USB cable to your PC.
3. Find the COM PORT number the device presents itself. 
   Example to find the port number: Click the windows icon at the bottom left of your screen. Type "device manager" and windows should find the program. If this latest step does not work on your computer there are two options: a) press Windows Key + R and run "devmgmt.msc" b) find the program under the menus.
   Then look under the "Ports (COM & LPT)" for the COM port (something like "Silicon Labs CP210x USB to UART Bridge (COM3)") - this brings us to COM3.
4. Edit appropriate .bat file UroflowUpload_ESP32.bat (for ESP32) and UroflowUpload_ESP8266.bat (for ESP8266) and CHANGE YOUR COM PORT!
5. Run the appropriate .bat file.

Alternative commands:
ESP32:
esptoolESP32.exe --chip esp32 --port COM3 --baud 921600 --before default_reset --after hard_reset write_flash -z --flash_mode dio --flash_freq 80m --flash_size detect 0xe000 esp32/partitions/boot_app0.bin 0x1000 esp32/sdk/bin/bootloader_dio_80m.bin 0x10000 Firmware/UroflowESP32.ino_ESP32.bin 0x8000 Firmware/UroflowESP32.ino.partitions_ESP32.bin

ESP8266:
esptoolESP8266.exe -vv -cd nodemcu -cb 115200 -cp COM3 -ca 0x00000 -cf Firmware/UroflowESP32.ino_ESP8266.bin

PART 2
======
After finding your IP address (with Fing for android or Advanced IP scanner for windows) enter into browser: "your-ip-address/upload". Mind the /upload! here you can select one-by-one file and upload it to your file system.


Any support is welcome,
Rok Rodic, 2018